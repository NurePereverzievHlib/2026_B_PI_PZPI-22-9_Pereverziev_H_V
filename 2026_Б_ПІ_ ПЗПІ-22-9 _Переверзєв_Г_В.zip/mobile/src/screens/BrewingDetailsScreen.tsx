import { MaterialIcons } from "@expo/vector-icons";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View
} from "react-native";
import Svg, { Path } from "react-native-svg";
import { CurrentUser, getCurrentUser } from "../api/auth";
import { getRecipe, Recipe } from "../api/recipes";
import { getScaleStatus, ScaleStatus } from "../api/scale";
import { advanceBrewingSession, BrewingSession, completeBrewingSession, createBrewingSession } from "../api/sessions";
import { BloomLogo } from "../components/BloomLogo";
import { ProfileBadge } from "../components/ProfileBadge";

type BrewingDetailsScreenProps = {
  recipeId: number;
  onBack: () => void;
  onOpenJournal: () => void;
  onSessionStarted: (sessionId: number, recipeId: number) => void;
};

function remoteImageSource(uri: string) {
  return {
    uri,
    headers: {
      Accept: "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
      "User-Agent": "Mozilla/5.0"
    }
  };
}

export function BrewingDetailsScreen({ recipeId, onBack, onOpenJournal, onSessionStarted }: BrewingDetailsScreenProps) {
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [profile, setProfile] = useState<CurrentUser | null>(null);
  const [scaleStatus, setScaleStatus] = useState<ScaleStatus | null>(null);
  const [session, setSession] = useState<BrewingSession | null>(null);
  const [failedHeroImage, setFailedHeroImage] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isStarting, setIsStarting] = useState(false);
  const [isAdvancing, setIsAdvancing] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const steps = useMemo(
    () => [...(recipe?.steps ?? [])].sort((a, b) => a.step_number - b.step_number),
    [recipe?.steps]
  );
  const totalWater = useMemo(() => steps.reduce((sum, step) => sum + Number(step.water_volume || 0), 0), [steps]);
  const plannedSeconds = getPlannedSeconds(recipe);
  const ratio = recipe?.coffee_grams ? Math.max(1, Math.round(totalWater / recipe.coffee_grams)) : 0;
  const poursCount = steps.filter((step) => isPourStep(step.step_type)).length || steps.length || 1;
  const currentStepIndex = Math.min(session?.current_step ?? 0, Math.max(steps.length, 1) - 1);
  const hasActiveSession = session?.status === "in_progress";
  const isCompleted = session?.status === "completed";

  async function loadDetails() {
    setIsLoading(true);

    try {
      const [recipeData, scaleData, profileData] = await Promise.all([
        getRecipe(recipeId),
        getScaleStatus(),
        getCurrentUser()
      ]);
      setRecipe(recipeData);
      setScaleStatus(scaleData);
      setProfile(profileData);
      setFailedHeroImage(false);
      setErrorMessage(null);
    } catch (error) {
      setErrorMessage(error instanceof Error ? error.message : "Не вдалося завантажити деталі рецепту.");
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadDetails();
  }, [recipeId]);

  useEffect(() => {
    const intervalId = setInterval(() => {
      getScaleStatus().then(setScaleStatus);
    }, 2000);

    return () => clearInterval(intervalId);
  }, []);

  async function startSession() {
    if (!recipe) {
      return;
    }

    setIsStarting(true);
    try {
      const created = await createBrewingSession(recipe.id, scaleStatus?.scaleId ?? null);
      setSession(created);
      onSessionStarted(created.id, recipe.id);
    } catch (error) {
      Alert.alert("Не вдалося почати", error instanceof Error ? error.message : "Спробуй ще раз.");
    } finally {
      setIsStarting(false);
    }
  }

  async function advanceStep() {
    if (!session) {
      return;
    }

    setIsAdvancing(true);
    try {
      const updated = await advanceBrewingSession(session.id);
      setSession(updated);
      if (updated.status === "completed") {
        Alert.alert("Заварювання завершено", "Сесію збережено в журналі.", [
          { text: "До журналу", onPress: onOpenJournal },
          { text: "Ок" }
        ]);
      }
    } catch (error) {
      Alert.alert("Не вдалося оновити крок", error instanceof Error ? error.message : "Спробуй ще раз.");
    } finally {
      setIsAdvancing(false);
    }
  }

  async function finishSession() {
    if (!session) {
      return;
    }

    setIsAdvancing(true);
    try {
      const updated = await completeBrewingSession(session.id);
      setSession(updated);
      Alert.alert("Готово", "Заварювання завершено і збережено в журналі.", [
        { text: "До журналу", onPress: onOpenJournal },
        { text: "Ок" }
      ]);
    } catch (error) {
      Alert.alert("Не вдалося завершити", error instanceof Error ? error.message : "Спробуй ще раз.");
    } finally {
      setIsAdvancing(false);
    }
  }

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.stateBox}>
          <ActivityIndicator color="#fc7240" />
          <Text style={styles.stateText}>Завантажуємо рецепт...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (errorMessage || !recipe) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.stateBox}>
          <MaterialIcons color="#fc7240" name="cloud-off" size={34} />
          <Text style={styles.stateText}>{errorMessage ?? "Рецепт не знайдено."}</Text>
          <Pressable accessibilityRole="button" onPress={onBack} style={styles.outlineButton}>
            <Text style={styles.outlineButtonText}>Назад</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <BloomLogo height={64} width={170} />
          <ProfileBadge profile={profile} />
        </View>

        <Pressable accessibilityRole="button" onPress={onBack} style={styles.detailsLink}>
          <MaterialIcons color="#fc7240" name="chevron-left" size={34} />
          <Text style={styles.detailsText}>Деталі рецепту</Text>
        </Pressable>

        <View style={styles.heroRow}>
          <View style={styles.heroCopy}>
            <View style={styles.methodBadge}>
              <BrewMethodIcon method={recipe.brew_method} />
              <Text numberOfLines={1} style={styles.methodBadgeText}>
                {recipe.brew_method}
              </Text>
            </View>
            <Text numberOfLines={2} style={styles.recipeTitle}>
              {recipe.name}
            </Text>
          </View>

          <View style={styles.heroArtWrap}>
            {recipe.coffee_image && !failedHeroImage ? (
              <Image
                onError={() => setFailedHeroImage(true)}
                resizeMode="contain"
                source={remoteImageSource(recipe.coffee_image)}
                style={styles.heroCoffeeImage}
              />
            ) : (
              <LineBloom width={178} height={168} />
            )}
          </View>
        </View>

        <View style={styles.metricRow}>
          <TopMetric icon={<CoffeeBeanIcon />} value={`${Math.round(recipe.coffee_grams)} гр`} label="Закладка" />
          <TopMetric icon={<RatioIcon />} value={ratio ? `1:${ratio}` : "1:0"} label="Ratio" />
          <TopMetric icon={<HourglassIcon color="#f07956" size={45} />} value={formatDuration(plannedSeconds)} label="Час" />
          <TopMetric icon={<WaterDropIcon />} value={`${poursCount}`} label="Вливань" />
        </View>

        <Text style={styles.sectionTitle}>Кроки</Text>

        <View style={styles.stepsList}>
          {steps.map((step, index) => {
            const nextStep = steps[index + 1];
            const waitSeconds = nextStep ? Math.max(0, nextStep.start_time - step.start_time) : Math.max(0, plannedSeconds - step.start_time);
            const isDone = hasActiveSession || isCompleted ? index < (session?.current_step ?? 0) : false;
            const isCurrent = hasActiveSession && index === currentStepIndex;

            return (
              <View key={step.id}>
                <StepCard
                  active={isCurrent}
                  done={isDone}
                  index={index}
                  pourRate={scaleStatus?.latestPourRate ?? null}
                  stepType={step.step_type}
                  volume={step.water_volume}
                  waitSeconds={waitSeconds}
                />
                {index < steps.length - 1 ? <StepDivider seconds={waitSeconds || 20} /> : null}
              </View>
            );
          })}
        </View>
      </ScrollView>

      <View style={styles.bottomBar}>
        {!hasActiveSession && !isCompleted ? (
          <Pressable accessibilityRole="button" disabled={isStarting} onPress={startSession} style={styles.primaryButton}>
            <Text style={styles.primaryButtonText}>{isStarting ? "Стартуємо..." : "Спробувати рецепт"}</Text>
          </Pressable>
        ) : hasActiveSession ? (
          <View style={styles.actionRow}>
            <Pressable accessibilityRole="button" disabled={isAdvancing} onPress={finishSession} style={styles.secondaryAction}>
              <Text style={styles.secondaryActionText}>Завершити</Text>
            </Pressable>
            <Pressable accessibilityRole="button" disabled={isAdvancing} onPress={advanceStep} style={styles.nextButton}>
              <Text style={styles.nextButtonText}>{isAdvancing ? "Оновлюємо..." : "Наступний крок"}</Text>
            </Pressable>
          </View>
        ) : (
          <Pressable accessibilityRole="button" onPress={onOpenJournal} style={styles.primaryButton}>
            <Text style={styles.primaryButtonText}>До журналу</Text>
          </Pressable>
        )}
      </View>
    </SafeAreaView>
  );
}

function TopMetric({ icon, value, label }: { icon: ReactNode; value: string; label: string }) {
  return (
    <View style={styles.topMetric}>
      <View style={styles.metricIcon}>{icon}</View>
      <Text numberOfLines={1} style={styles.metricValue}>
        {value}
      </Text>
      <Text numberOfLines={1} style={styles.metricLabel}>
        {label}
      </Text>
    </View>
  );
}

function StepCard({
  active,
  done,
  index,
  pourRate,
  stepType,
  volume,
  waitSeconds
}: {
  active: boolean;
  done: boolean;
  index: number;
  pourRate: number | null;
  stepType: string;
  volume: number;
  waitSeconds: number;
}) {
  return (
    <View style={[styles.stepCard, active && styles.stepCardActive, done && styles.stepCardDone]}>
      <View style={styles.stepIconWrap}>
        <StepTypeIcon stepType={stepType} />
      </View>

      <View style={styles.stepNameBlock}>
        <Text numberOfLines={2} style={styles.stepName}>
          {stepType || `Крок ${index + 1}`}
        </Text>
      </View>

      <View style={styles.stepMetaBlock}>
        <View style={styles.stepMetaRow}>
          <MaterialIcons color="#111111" name="speed" size={22} />
          <Text style={styles.stepMetaText}>{pourRate === null ? "—" : pourRate.toFixed(1)} гр/с</Text>
        </View>
        <View style={styles.stepMetaRow}>
          <HourglassIcon color="#111111" size={26} />
          <Text style={styles.stepMetaText}>{Math.max(5, Math.round(waitSeconds || volume / 10))} сек</Text>
        </View>
      </View>
    </View>
  );
}

function StepDivider({ seconds }: { seconds: number }) {
  return (
    <View style={styles.stepDivider}>
      <View style={styles.dividerLine} />
      <Text style={styles.dividerText}>{Math.max(1, Math.round(seconds))} сек</Text>
      <View style={styles.dividerLine} />
    </View>
  );
}

function StepTypeIcon({ stepType }: { stepType: string }) {
  const normalized = normalizeText(stepType);

  if (normalized.includes("bloom") || normalized.includes("блюм")) {
    return <LineBloom width={58} height={54} />;
  }

  if (normalized.includes("wait") || normalized.includes("чек")) {
    return (
      <View style={styles.waterIconCircle}>
        <HourglassIcon color="#111111" size={32} />
      </View>
    );
  }

  if (normalized.includes("finish") || normalized.includes("фіні") || normalized.includes("фини")) {
    return (
      <View style={styles.orangeIconCircle}>
        <BloomMarkIcon />
      </View>
    );
  }

  return (
    <View style={styles.waterIconCircle}>
      <WaterDropIcon />
    </View>
  );
}

function BrewMethodIcon({ method }: { method: string }) {
  const normalized = normalizeText(method);

  if (normalized.includes("aeropress") || normalized.includes("aero press")) {
    return (
      <Svg height={31} viewBox="0 0 19 32" width={19}>
        <Path
          d="M12.64 0C13.82-.01 14.42-.01 14.99.48c.08.08.07.15.07.26 0 .2-.04.33-.19.48-.17.13-.35.2-.54.27-.68.22-1.41.28-2.12.33-2 .13-3.99.19-6 .17.1.27.11.54.12.84.04.74.09 1.48.09 2.22 0 .61 0 .61-.06.73 1.98.04 3.96.1 5.93.01-.02-.03-.04-.07-.06-.1-.01-.09-.01-.18-.01-.28 0-1.17.01-2.34.05-3.51.03-.7.03-.7.23-.91.13.01.13.01.25.05.11.16.12.2.12.39-.01 1.5-.08 3-.13 4.5.36-.01.72.03 1.06.16.08.11.13.16.16.29.09 1.66.1 3.32.14 4.98.06 2.52.07 5.04.1 7.56.03 2.35.09 4.7.1 7.05 0 .3-.01.53-.17.8-.14.05-.14.05-.26.05-.16-.25-.16-.49-.16-.78-.06-3.53-.11-7.05-.19-10.58-.05-2.02-.05-4.04-.04-6.06h-.61c-.23.13-.48.14-.74.17-.75.07-1.5.07-2.25.06-2.92 0-2.92 0-3.57-.32.01 2.37-.01 4.74-.05 7.12-.05 2.48-.08 4.96-.1 7.44-.01.78-.01 1.56-.09 2.34.14.03.28.05.42.07.98.16 2 .12 2.99.12 1.32.01 2.63-.02 3.94-.23.27-.04.53-.04.8-.03.02.08.03.17.05.25-.44.46-1.37.43-1.97.5-.83.11-1.66.1-2.49.1-2.15 0-2.15 0-3.01-.15-.71-.12-.71-.12-.92-.34.02-.13.02-.13.05-.25-.12-.03-.12-.03-.25-.05-.05.03-.1.07-.15.1-.07.02-.15.03-.22.04-.42.08-.83.23-1.14.52.35.24.69.35 1.1.44 2.81.59 5.88.41 8.72.13.62-.06 1.22-.18 1.82-.35.25-.07.46-.16.68-.3v-.15c-.37-.2-.73-.35-1.15-.38-.15-.01-.19-.02-.31-.12-.04-.11-.04-.11-.03-.22.04-.09.04-.09.14-.19.58-.06 1.29.13 1.76.47.15.13.23.24.27.44.01.22-.06.34-.21.51-1.13 1.19-4.03 1.06-5.57 1.1-1.48.04-2.96.04-4.44-.1-.56-.05-1.12-.13-1.67-.24-.63-.13-1.23-.3-1.62-.84-.08-.16-.07-.33-.05-.51.23-.44.82-.61 1.26-.77.18-.05.34-.05.52-.05h.29v-.19c-.01-3.21.01-6.42.08-9.63.04-1.9.06-3.8.11-5.7.01-.36.02-.72.04-1.07.03-.13.07-.18.18-.26.13-.02.25-.03.38-.04.22-.01.22-.01.32-.01-.02-.17-.04-.35-.06-.52-.05-.87-.09-1.74-.09-2.61 0-.33 0-.66 0-.98 0-.21.02-.34.17-.49-1.51-.03-2.02-.05-2.53-.51-.08-.16-.07-.28-.05-.46.28-.36.74-.47 1.17-.53.72-.1 1.45-.15 2.18-.19 1.35-.09 2.7-.18 4.05-.26 1.16-.08 2.31-.13 3.48-.14Z"
          fill="#111111"
        />
      </Svg>
    );
  }

  if (normalized.includes("v60") || normalized.includes("v-60") || normalized.includes("hario") || normalized.includes("pour")) {
    return <MaterialIcons color="#111111" name="filter-alt" size={30} />;
  }

  if (normalized.includes("french") || normalized.includes("press")) {
    return (
      <Svg height={30} viewBox="0 0 30 30" width={30}>
        <Path d="M9 5h12v3h-1v16H10V8H9V5Zm3 5v12h6V10h-6Zm-2 15h10v2H10v-2ZM7 8h2v13H7V8Zm14 0h2v13h-2V8Z" fill="#111111" />
      </Svg>
    );
  }

  return <MaterialIcons color="#111111" name="local-cafe" size={30} />;
}

function LineBloom({ width = 166, height = 156 }: { width?: number; height?: number }) {
  return (
    <Svg height={height} viewBox="0 0 166 156" width={width}>
      <Path
        d="M67.002 85.4342C62.3944 86.2504 48.2113 90.6284 38.8856 97.4962C28.9833 104.789 26.8627 116.434 22.4684 129.902C21.3418 133.355 21.9109 137.029 22.8579 139.532C23.8048 142.034 25.6986 143.394 27.7564 144.231C39.8256 149.139 57.6722 145.076 67.9161 141.519C82.0908 136.596 87.1863 111.125 88.5964 93.8644C89.0107 88.7935 84.5054 85.4507 81.1031 82.4331C73.461 75.6552 63.493 78.014 56.9343 79.6464C54.2569 80.3128 54.7043 84.5438 55.3807 86.9059C56.5488 90.9852 60.4268 93.3903 63.8332 95.7236C67.118 97.9735 71.8963 97.8013 76.262 97.1211C78.2836 96.8061 79.5454 95.0805 80.5128 93.2914C82.5298 89.5613 82.5788 84.0903 81.6319 78.7395C81.1888 76.2358 78.7912 74.7491 76.8686 73.636C74.9461 72.523 73.0523 71.9789 71.2651 72.2427C69.4778 72.5065 67.8545 73.5948 67.2888 75.2438C66.7232 76.8927 67.2643 79.0693 68.4899 80.7347C73.5115 87.558 81.4474 91.7331 91.0149 98.3248C98.6083 103.556 106.043 108.767 113.704 112.493C117.313 114.249 121.365 114.291 125.452 113.882C139.255 112.504 154.675 97.0262 159.361 88.0766C161.243 84.4811 160.463 79.6877 159.381 74.6172C156.741 62.2477 143.017 57.4352 132.085 51.5114C118.576 44.1916 86.8256 54.8794 73.45 61.7761C69.6794 63.7202 70.2813 70.5608 71.0929 76.1878C71.4497 78.661 73.5278 79.9102 75.5815 80.611C77.6352 81.3118 80.0701 81.3118 82.4066 80.3596C92.6174 76.1981 94.0401 59.3975 94.3352 41.9435C94.6423 23.7853 82.3328 12.9139 70.3304 4.11687C65.7674 0.772491 58.8445 1.3384 52.0194 2.01859C43.2491 2.89263 37.5206 13.3921 30.5438 22.6014C27.3942 26.759 26.2889 31.819 25.6043 36.4813C25.0058 40.5574 28.1745 44.7384 32.536 48.8525C40.7861 56.6345 52.4744 58.2102 61.2303 59.8715C65.5496 60.691 71.3389 60.7001 75.5856 60.02C84.7558 58.5512 45.5386 54.1044 29.9002 59.5624C14.045 65.0961 5.79292 75.7962 5.51421 79.7701C5.20245 84.2152 10.1381 87.6191 15.4465 90.2244C33.0525 93.6789 47.58 92.8627 51.5316 91.0818C53.5894 90.1172 55.7537 89.0289 59.6234 87.9076"
        fill="none"
        stroke="#111111"
        strokeLinecap="round"
        strokeWidth={3}
      />
    </Svg>
  );
}

function WaterDropIcon({ size = 35 }: { size?: number }) {
  return (
    <Svg height={size} viewBox="0 0 28 35" width={(size * 28) / 35}>
      <Path
        d="M14.4813 29.75C14.8313 29.7208 15.1302 29.5823 15.3781 29.3344C15.626 29.0865 15.75 28.7875 15.75 28.4375C15.75 28.0292 15.6188 27.701 15.3563 27.4531C15.0938 27.2052 14.7583 27.0958 14.35 27.125C13.1542 27.2125 11.8854 26.8844 10.5437 26.1406C9.20208 25.3969 8.35625 24.0479 8.00625 22.0938C7.94792 21.7729 7.79479 21.5104 7.54688 21.3062C7.29896 21.1021 7.01458 21 6.69375 21C6.28542 21 5.95 21.1531 5.6875 21.4594C5.425 21.7656 5.3375 22.1229 5.425 22.5312C5.92083 25.1854 7.0875 27.0812 8.925 28.2188C10.7625 29.3563 12.6146 29.8667 14.4813 29.75ZM4.00313 30.8875C1.33438 28.1458 0 24.7333 0 20.65C0 17.7333 1.15938 14.5615 3.47813 11.1344C5.79688 7.70729 9.30417 3.99583 14 0C18.6958 3.99583 22.2031 7.70729 24.5219 11.1344C26.8406 14.5615 28 17.7333 28 20.65C28 24.7333 26.6656 28.1458 23.9969 30.8875C21.3281 33.6292 17.9958 35 14 35C10.0042 35 6.67188 33.6292 4.00313 30.8875ZM21.525 28.4156C23.5083 26.3594 24.5 23.7708 24.5 20.65C24.5 18.5208 23.6177 16.1146 21.8531 13.4313C20.0885 10.7479 17.4708 7.81667 14 4.6375C10.5292 7.81667 7.91146 10.7479 6.14687 13.4313C4.38229 16.1146 3.5 18.5208 3.5 20.65C3.5 23.7708 4.49167 26.3594 6.475 28.4156C8.45833 30.4719 10.9667 31.5 14 31.5C17.0333 31.5 19.5417 30.4719 21.525 28.4156Z"
        fill="#406FFC"
      />
    </Svg>
  );
}

function CoffeeBeanIcon() {
  return (
    <Svg height={45} viewBox="0 0 45 45" width={45}>
      <Path
        d="M20.4 4.5C11.2 7.4 5.5 15 5.5 24.2c0 8.5 4.7 15.1 12.6 17.6 2.2-6.2 2.1-12.3-.4-18.5-2.3-5.8-1.4-12.3 2.7-18.8ZM25.2 40.6c8.8-3 14.3-10.5 14.3-19.6 0-8.3-4.4-14.7-12-17.3-2.1 6.4-2 12.6.5 18.6 2.3 5.7 1.4 12-2.8 18.3Z"
        fill="#f07956"
      />
    </Svg>
  );
}

function RatioIcon() {
  return <MaterialIcons color="#f07956" name="tune" size={45} />;
}

function BloomMarkIcon() {
  return <MaterialIcons color="#fc7240" name="wb-sunny" size={39} />;
}

function HourglassIcon({ color = "#f07956", size = 45 }: { color?: string; size?: number }) {
  return <MaterialIcons color={color} name="hourglass-empty" size={size} />;
}

function normalizeText(value: string) {
  return value.trim().toLowerCase();
}

function isPourStep(value: string) {
  const normalized = value.toLowerCase();
  return normalized.includes("лив") || normalized.includes("pour") || normalized.includes("вливан");
}

function normalizeStepName(value: string, index: number) {
  if (index === 0) {
    return "Блюмінг";
  }
  if (index === 1) {
    return "Наступне\nвливання";
  }
  if (index === 2) {
    return "Останнє\nвливання";
  }
  return value || `Крок ${index + 1}`;
}

function getPlannedSeconds(recipe: Recipe | null) {
  if (!recipe) {
    return 0;
  }

  const [minutes, seconds] = recipe.total_time.split(":").map((part) => Number(part));
  if (Number.isFinite(minutes) && Number.isFinite(seconds)) {
    return minutes * 60 + seconds;
  }

  return recipe.steps.reduce((max, step) => Math.max(max, step.start_time), 0);
}

function formatDuration(seconds: number) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = String(Math.round(seconds % 60)).padStart(2, "0");
  return `${minutes}:${remainingSeconds}`;
}

const styles = StyleSheet.create({
  safeArea: {
    backgroundColor: "#ffffff",
    flex: 1
  },
  stateBox: {
    alignItems: "center",
    flex: 1,
    gap: 12,
    justifyContent: "center",
    padding: 24
  },
  stateText: {
    color: "#333333",
    fontFamily: "Manrope_500Medium",
    fontSize: 14,
    lineHeight: 20,
    textAlign: "center"
  },
  scrollContent: {
    paddingBottom: 104
  },
  header: {
    alignItems: "center",
    flexDirection: "row",
    height: 76,
    justifyContent: "space-between",
    paddingHorizontal: 12,
    paddingTop: 8
  },
  detailsLink: {
    alignItems: "center",
    flexDirection: "row",
    marginLeft: 7,
    marginTop: 2
  },
  detailsText: {
    color: "#646464",
    fontFamily: "Manrope_700Bold",
    fontSize: 11
  },
  heroRow: {
    flexDirection: "row",
    minHeight: 174,
    paddingHorizontal: 15,
    paddingTop: 24
  },
  heroCopy: {
    flex: 1
  },
  methodBadge: {
    alignItems: "center",
    alignSelf: "flex-start",
    backgroundColor: "#d9d9d9",
    borderRadius: 8,
    flexDirection: "row",
    gap: 10,
    height: 46,
    maxWidth: 172,
    paddingHorizontal: 17
  },
  methodBadgeText: {
    color: "#111111",
    flexShrink: 1,
    fontFamily: "Manrope_700Bold",
    fontSize: 16
  },
  recipeTitle: {
    color: "#000000",
    fontFamily: "serif",
    fontSize: 36,
    fontWeight: "700",
    lineHeight: 41,
    marginTop: 22
  },
  heroArtWrap: {
    alignItems: "center",
    justifyContent: "flex-start",
    marginRight: -6,
    marginTop: -20,
    width: 188
  },
  heroCoffeeImage: {
    height: 168,
    width: 178
  },
  metricRow: {
    flexDirection: "row",
    gap: 10,
    justifyContent: "center",
    paddingHorizontal: 14,
    paddingTop: 14
  },
  topMetric: {
    alignItems: "center",
    borderColor: "#fc7240",
    borderRadius: 8,
    borderWidth: 1,
    height: 122,
    justifyContent: "center",
    paddingHorizontal: 4,
    width: "23.2%"
  },
  metricIcon: {
    alignItems: "center",
    height: 48,
    justifyContent: "center"
  },
  metricValue: {
    color: "#111111",
    fontFamily: "Manrope_700Bold",
    fontSize: 21,
    lineHeight: 25,
    marginTop: 7
  },
  metricLabel: {
    color: "#666666",
    fontFamily: "Manrope_500Medium",
    fontSize: 15,
    lineHeight: 19,
    marginTop: 2
  },
  sectionTitle: {
    color: "#000000",
    fontFamily: "Manrope_700Bold",
    fontSize: 36,
    lineHeight: 44,
    marginLeft: 15,
    marginTop: 27
  },
  stepsList: {
    paddingHorizontal: 14,
    paddingTop: 14
  },
  stepCard: {
    alignItems: "center",
    backgroundColor: "#ffffff",
    borderColor: "#111111",
    borderRadius: 8,
    borderWidth: 1,
    flexDirection: "row",
    height: 82,
    paddingLeft: 9,
    paddingRight: 10
  },
  stepCardActive: {
    borderColor: "#fc7240"
  },
  stepCardDone: {
    backgroundColor: "#fafafa"
  },
  stepIconWrap: {
    alignItems: "center",
    height: 60,
    justifyContent: "center",
    width: 72
  },
  waterIconCircle: {
    alignItems: "center",
    backgroundColor: "#d9d9d9",
    borderRadius: 24,
    height: 48,
    justifyContent: "center",
    width: 48
  },
  orangeIconCircle: {
    alignItems: "center",
    backgroundColor: "#d9d9d9",
    borderRadius: 24,
    height: 48,
    justifyContent: "center",
    width: 48
  },
  stepNameBlock: {
    flex: 1,
    justifyContent: "center"
  },
  stepName: {
    color: "#000000",
    fontFamily: "serif",
    fontSize: 30,
    fontWeight: "700",
    lineHeight: 36
  },
  stepMetaBlock: {
    gap: 6,
    width: 120
  },
  stepMetaRow: {
    alignItems: "center",
    flexDirection: "row",
    gap: 6
  },
  stepMetaText: {
    color: "#111111",
    fontFamily: "Manrope_500Medium",
    fontSize: 16
  },
  stepDivider: {
    alignItems: "center",
    flexDirection: "row",
    gap: 13,
    height: 26
  },
  dividerLine: {
    backgroundColor: "#111111",
    flex: 1,
    height: 1
  },
  dividerText: {
    color: "#111111",
    fontFamily: "Manrope_700Bold",
    fontSize: 21,
    lineHeight: 26
  },
  bottomBar: {
    backgroundColor: "rgba(255,255,255,0.96)",
    bottom: 0,
    left: 0,
    paddingBottom: 12,
    paddingHorizontal: 61,
    paddingTop: 10,
    position: "absolute",
    right: 0
  },
  primaryButton: {
    alignItems: "center",
    backgroundColor: "#e5795c",
    borderRadius: 15,
    height: 58,
    justifyContent: "center"
  },
  primaryButtonText: {
    color: "#ffffff",
    fontFamily: "Manrope_700Bold",
    fontSize: 24
  },
  actionRow: {
    flexDirection: "row",
    gap: 10,
    marginHorizontal: -45
  },
  secondaryAction: {
    alignItems: "center",
    borderColor: "#111111",
    borderRadius: 15,
    borderWidth: 1,
    flex: 0.85,
    height: 58,
    justifyContent: "center"
  },
  secondaryActionText: {
    color: "#111111",
    fontFamily: "Manrope_700Bold",
    fontSize: 16
  },
  nextButton: {
    alignItems: "center",
    backgroundColor: "#e5795c",
    borderRadius: 15,
    flex: 1.15,
    height: 58,
    justifyContent: "center"
  },
  nextButtonText: {
    color: "#ffffff",
    fontFamily: "Manrope_700Bold",
    fontSize: 16
  },
  outlineButton: {
    alignItems: "center",
    borderColor: "#111111",
    borderRadius: 10,
    borderWidth: 1,
    height: 42,
    justifyContent: "center",
    paddingHorizontal: 18
  },
  outlineButtonText: {
    color: "#111111",
    fontFamily: "Manrope_700Bold",
    fontSize: 15
  }
});
