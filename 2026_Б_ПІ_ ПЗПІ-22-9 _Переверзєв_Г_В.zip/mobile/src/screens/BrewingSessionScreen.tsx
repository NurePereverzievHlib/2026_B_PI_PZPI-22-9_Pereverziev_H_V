import { MaterialIcons } from "@expo/vector-icons";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Svg, { Circle } from "react-native-svg";
import { getRecipe, Recipe } from "../api/recipes";
import { getScaleStatus } from "../api/scale";
import {
  advanceBrewingSession,
  completeBrewingSession,
  getSensorWebSocketUrl,
} from "../api/sessions";

type BrewingSessionScreenProps = {
  sessionId: number;
  recipeId: number;
  onBackToRecipe: () => void;
  onFinished: () => void;
};

type SensorSnapshot = {
  weight: number;
  pourRate: number;
  timestamp: number;
};

type GuidanceTone = "offline" | "stop" | "fast" | "slow" | "wait" | "done" | "good";

type Guidance = {
  tone: GuidanceTone;
  title: string;
  message: string;
  icon: keyof typeof MaterialIcons.glyphMap;
};

const POUR_TOLERANCE = 0.35;
const OVERPOUR_GRAMS = 5;
const WS_STALE_MS = 3500;
const STEP_ALIASES = new Map([
  ["bloom", "Блюмінг"],
  ["blooming", "Блюмінг"],
  ["pour", "Налив"],
  ["wait", "Пауза"],
  ["pause", "Пауза"],
  ["finish", "Фініш"],
]);

export function BrewingSessionScreen({
  sessionId,
  recipeId,
  onBackToRecipe,
  onFinished,
}: BrewingSessionScreenProps) {
  const [recipe, setRecipe] = useState<Recipe | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isFinishing, setIsFinishing] = useState(false);
  const [elapsedSeconds, setElapsedSeconds] = useState(0);
  const [wsConnected, setWsConnected] = useState(false);
  const [scaleConnected, setScaleConnected] = useState(false);
  const [lastLiveSensorAt, setLastLiveSensorAt] = useState(0);
  const [syncedStepIndex, setSyncedStepIndex] = useState(0);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [sensor, setSensor] = useState<SensorSnapshot>({
    weight: 0,
    pourRate: 0,
    timestamp: 0,
  });

  const lastSensorRef = useRef<SensorSnapshot>({
    weight: 0,
    pourRate: 0,
    timestamp: 0,
  });
  const isSyncingStepRef = useRef(false);

  useEffect(() => {
    let isMounted = true;

    async function loadRecipe() {
      try {
        setIsLoading(true);
        setErrorMessage(null);
        const data = await getRecipe(recipeId);
        if (isMounted) {
          setRecipe(data);
        }
      } catch (error) {
        if (isMounted) {
          setErrorMessage("Не вдалося завантажити рецепт для заварювання.");
        }
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    loadRecipe();

    return () => {
      isMounted = false;
    };
  }, [recipeId]);

  useEffect(() => {
    const timer = setInterval(() => {
      setElapsedSeconds((value) => value + 1);
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    let isMounted = true;
    let socket: WebSocket | null = null;

    function updateSensorFromPayload(weight: number, pourRate?: number, isLive = true) {
      const now = Date.now();
      const previous = lastSensorRef.current;
      const seconds = previous.timestamp > 0 ? (now - previous.timestamp) / 1000 : 0;
      const derivedRate =
        seconds > 0 ? Math.max(0, (weight - previous.weight) / seconds) : previous.pourRate;
      const nextSnapshot = {
        weight: Math.max(0, weight),
        pourRate: Math.max(0, typeof pourRate === "number" ? pourRate : derivedRate),
        timestamp: now,
      };

      lastSensorRef.current = nextSnapshot;

      if (isMounted) {
        setSensor(nextSnapshot);
        if (isLive) {
          setLastLiveSensorAt(now);
        }
      }
    }

    function connectWebSocket() {
      socket = new WebSocket(getSensorWebSocketUrl(sessionId));

      socket.onopen = () => {
        if (isMounted) {
          setWsConnected(true);
        }
      };

      socket.onclose = () => {
        if (isMounted) {
          setWsConnected(false);
        }
      };

      socket.onerror = () => {
        if (isMounted) {
          setWsConnected(false);
        }
      };

      socket.onmessage = (event) => {
        try {
          const payload = JSON.parse(event.data);
          const weight = Number(payload.weight);
          const pourRate = Number(payload.pour_rate);

          if (Number.isFinite(weight)) {
            updateSensorFromPayload(weight, Number.isFinite(pourRate) ? pourRate : undefined, true);
            if (isMounted) {
              setScaleConnected(true);
            }
          }
        } catch {
          // Ignore non-sensor messages.
        }
      };
    }

    connectWebSocket();

    const fallbackTimer = setInterval(async () => {
      try {
        const status = await getScaleStatus();
        const hasRecentWebSocket = Date.now() - lastSensorRef.current.timestamp < 2500;

        if (isMounted) {
          setScaleConnected(status.connected);
        }

        if (!hasRecentWebSocket && typeof status.latestWeight === "number") {
          updateSensorFromPayload(
            status.latestWeight,
            status.latestPourRate ?? undefined,
            status.connected,
          );
        }
      } catch {
        if (isMounted) {
          setScaleConnected(false);
        }
      }
    }, 1500);

    return () => {
      isMounted = false;
      clearInterval(fallbackTimer);
      socket?.close();
    };
  }, [sessionId]);

  const steps = useMemo(() => {
    return [...(recipe?.steps ?? [])].sort((a, b) => a.step_number - b.step_number);
  }, [recipe?.steps]);

  const plannedSeconds = useMemo(() => getPlannedSeconds(steps), [steps]);
  const totalTarget = useMemo(
    () => steps.reduce((sum, step) => sum + Number(step.water_volume || 0), 0),
    [steps],
  );

  const isScaleOnline = scaleConnected && Date.now() - lastLiveSensorAt < WS_STALE_MS;
  const timeStepIndex = getCurrentStepIndexByTime(steps, elapsedSeconds);
  const weightStepIndex = isScaleOnline ? getCurrentStepIndexByWeight(steps, sensor.weight) : syncedStepIndex;
  const currentStepIndex = Math.min(
    Math.max(Math.min(timeStepIndex, weightStepIndex), syncedStepIndex),
    Math.max(steps.length - 1, 0),
  );
  const currentStep = steps[currentStepIndex];
  const nextStep = steps[currentStepIndex + 1];
  const previousTarget = getCumulativeTarget(steps, currentStepIndex);
  const currentTarget = previousTarget + Number(currentStep?.water_volume || 0);
  const stepEndSecond = nextStep?.start_time ?? plannedSeconds;
  const remainingStepGrams = Math.max(0, currentTarget - sensor.weight);
  const remainingStepSeconds = Math.max(1, stepEndSecond - elapsedSeconds);
  const targetPourRate = isWaitStep(currentStep?.step_type) ? 0 : remainingStepGrams / remainingStepSeconds;
  const recipeProgress = totalTarget > 0 ? Math.min(sensor.weight / totalTarget, 1) : 0;
  const stepProgress = currentTarget > 0 ? Math.min(sensor.weight / currentTarget, 1) : 0;
  const guidance = getGuidance({
    isScaleOnline,
    currentStepType: currentStep?.step_type,
    currentWeight: sensor.weight,
    currentTarget,
    totalTarget,
    pourRate: sensor.pourRate,
    targetPourRate,
  });

  useEffect(() => {
    if (currentStepIndex <= syncedStepIndex || isSyncingStepRef.current) {
      return;
    }

    let isCancelled = false;

    async function syncBackendStep() {
      isSyncingStepRef.current = true;

      try {
        for (let step = syncedStepIndex; step < currentStepIndex; step += 1) {
          if (isCancelled) {
            return;
          }

          await advanceBrewingSession(sessionId);
        }

        if (!isCancelled) {
          setSyncedStepIndex(currentStepIndex);
        }
      } catch {
        if (!isCancelled) {
          setErrorMessage("Не вдалося синхронізувати поточний крок із сервером.");
        }
      } finally {
        isSyncingStepRef.current = false;
      }
    }

    syncBackendStep();

    return () => {
      isCancelled = true;
    };
  }, [currentStepIndex, sessionId, syncedStepIndex]);

  async function finishBrewing() {
    try {
      setIsFinishing(true);
      await completeBrewingSession(sessionId);
      onFinished();
    } catch {
      Alert.alert("Помилка", "Не вдалося завершити заварювання. Спробуй ще раз.");
    } finally {
      setIsFinishing(false);
    }
  }

  if (isLoading) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.centered}>
          <ActivityIndicator color="#E36E49" />
          <Text style={styles.loadingText}>Готуємо сесію...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!recipe || steps.length === 0) {
    return (
      <SafeAreaView style={styles.safeArea}>
        <View style={styles.centered}>
          <Text style={styles.errorTitle}>Немає кроків</Text>
          <Text style={styles.errorText}>
            Для цього рецепту потрібно додати етапи заварювання.
          </Text>
          <Pressable style={styles.secondaryButton} onPress={onBackToRecipe}>
            <Text style={styles.secondaryButtonText}>Назад</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        <View style={styles.topBar}>
          <Pressable style={styles.iconButton} onPress={onBackToRecipe}>
            <MaterialIcons name="chevron-left" size={30} color="#171717" />
          </Pressable>

          <View style={[styles.connectionPill, !isScaleOnline && styles.connectionPillOffline]}>
            <View style={[styles.connectionDot, !isScaleOnline && styles.connectionDotOffline]} />
            <Text style={styles.connectionText}>{isScaleOnline ? "Ваги онлайн" : "Ваги офлайн"}</Text>
          </View>
        </View>

        <Text style={styles.recipeName}>{recipe.name}</Text>
        <Text style={styles.recipeMeta}>
          Крок {currentStepIndex + 1}/{steps.length} · {formatDuration(elapsedSeconds)}
        </Text>

        {errorMessage ? <Text style={styles.inlineError}>{errorMessage}</Text> : null}

        <GuidanceCard guidance={guidance} />

        <View style={styles.weightPanel}>
          <ProgressRing progress={recipeProgress} tone={guidance.tone} />
          <View style={styles.weightCenter}>
            <Text style={styles.weightLabel}>Вага в чашці</Text>
            <Text style={styles.weightValue}>{sensor.weight.toFixed(1)} г</Text>
            <Text style={styles.weightHint}>ціль {totalTarget.toFixed(0)} г</Text>
          </View>
        </View>

        <View style={styles.metricsRow}>
          <Metric label="Потік" value={`${sensor.pourRate.toFixed(1)} г/с`} />
          <Metric label="Ціль потоку" value={`${targetPourRate.toFixed(1)} г/с`} />
          <Metric label="До етапу" value={`${remainingStepGrams.toFixed(0)} г`} />
        </View>

        <View style={styles.stepCard}>
          <View style={styles.stepHeader}>
            <View>
              <Text style={styles.stepEyebrow}>Поточний етап</Text>
              <Text style={styles.stepTitle}>{getStepTitle(currentStep.step_type, currentStepIndex)}</Text>
            </View>
            <Text style={styles.stepTime}>{formatDuration(Math.max(0, stepEndSecond - elapsedSeconds))}</Text>
          </View>

          <Text style={styles.stepInstruction}>
            {getStepInstruction(currentStep.step_type, currentTarget, remainingStepGrams)}
          </Text>

          <View style={styles.progressTrack}>
            <View style={[styles.progressFill, { width: `${Math.round(stepProgress * 100)}%` }]} />
          </View>

          <View style={styles.stepFooter}>
            <Text style={styles.stepFooterText}>Зараз {sensor.weight.toFixed(1)} г</Text>
            <Text style={styles.stepFooterText}>Етап до {currentTarget.toFixed(0)} г</Text>
          </View>
        </View>

        <View style={styles.planCard}>
          <Text style={styles.planTitle}>План заварювання</Text>
          {steps.map((step, index) => {
            const isActive = index === currentStepIndex;
            const isDone = index < currentStepIndex;
            const target = getCumulativeTarget(steps, index + 1);

            return (
              <View
                key={step.id}
                style={[
                  styles.planRow,
                  isActive && styles.planRowActive,
                  isDone && styles.planRowDone,
                ]}
              >
                <View style={[styles.planNumber, isActive && styles.planNumberActive]}>
                  <Text style={[styles.planNumberText, isActive && styles.planNumberTextActive]}>
                    {index + 1}
                  </Text>
                </View>
                <View style={styles.planBody}>
                  <Text style={styles.planStepTitle}>{getStepTitle(step.step_type, index)}</Text>
                  <Text style={styles.planStepMeta}>
                    {formatDuration(step.start_time)} · до {target.toFixed(0)} г
                  </Text>
                </View>
                {isDone ? <MaterialIcons name="check-circle" size={22} color="#4EBA61" /> : null}
              </View>
            );
          })}
        </View>
      </ScrollView>

      <View style={styles.bottomBar}>
        <Pressable
          style={[styles.finishButton, isFinishing && styles.finishButtonDisabled]}
          onPress={finishBrewing}
          disabled={isFinishing}
        >
          <Text style={styles.finishButtonText}>
            {isFinishing ? "Завершуємо..." : "Завершити заварювання"}
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

function GuidanceCard({ guidance }: { guidance: Guidance }) {
  return (
    <View style={[styles.guidanceCard, styles[`guidance_${guidance.tone}`]]}>
      <View style={styles.guidanceIconWrap}>
        <MaterialIcons name={guidance.icon} size={28} color="#171717" />
      </View>
      <View style={styles.guidanceTextWrap}>
        <Text style={styles.guidanceTitle}>{guidance.title}</Text>
        <Text style={styles.guidanceMessage}>{guidance.message}</Text>
      </View>
    </View>
  );
}

function ProgressRing({ progress, tone }: { progress: number; tone: GuidanceTone }) {
  const size = 238;
  const strokeWidth = 14;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - progress);

  return (
    <Svg width={size} height={size} style={styles.progressRing}>
      <Circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke="#EEE6DF"
        strokeWidth={strokeWidth}
        fill="#F7F2EC"
      />
      <Circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke={getToneColor(tone)}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        fill="transparent"
        strokeDasharray={`${circumference} ${circumference}`}
        strokeDashoffset={offset}
        rotation="-90"
        originX={size / 2}
        originY={size / 2}
      />
    </Svg>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <View style={styles.metricCard}>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricLabel}>{label}</Text>
    </View>
  );
}

function getGuidance({
  isScaleOnline,
  currentStepType,
  currentWeight,
  currentTarget,
  totalTarget,
  pourRate,
  targetPourRate,
}: {
  isScaleOnline: boolean;
  currentStepType?: string;
  currentWeight: number;
  currentTarget: number;
  totalTarget: number;
  pourRate: number;
  targetPourRate: number;
}): Guidance {
  if (!isScaleOnline) {
    return {
      tone: "offline",
      title: "Ваги не передають дані",
      message: "Перевір WebSocket сесії та живлення ESP32.",
      icon: "cloud-off",
    };
  }

  if (currentWeight >= totalTarget - 1 && totalTarget > 0) {
    return {
      tone: "done",
      title: "Рецепт майже готовий",
      message: "Можна завершувати заварювання та зберегти результат.",
      icon: "check-circle",
    };
  }

  if (currentWeight > currentTarget + OVERPOUR_GRAMS) {
    return {
      tone: "stop",
      title: "Зупини налив",
      message: `Етап перелито на ${(currentWeight - currentTarget).toFixed(0)} г.`,
      icon: "front-hand",
    };
  }

  if (isWaitStep(currentStepType)) {
    return {
      tone: "wait",
      title: "Пауза",
      message: "Дай каві стекти перед наступним етапом.",
      icon: "hourglass-empty",
    };
  }

  if (targetPourRate > 0.1 && pourRate > targetPourRate * (1 + POUR_TOLERANCE)) {
    return {
      tone: "fast",
      title: "Повільніше",
      message: `Ти ллєш ${pourRate.toFixed(1)} г/с, ціль близько ${targetPourRate.toFixed(1)} г/с.`,
      icon: "trending-up",
    };
  }

  if (targetPourRate > 0.4 && pourRate < targetPourRate * (1 - POUR_TOLERANCE)) {
    return {
      tone: "slow",
      title: "Трохи швидше",
      message: `Поточний потік ${pourRate.toFixed(1)} г/с, ціль близько ${targetPourRate.toFixed(1)} г/с.`,
      icon: "trending-down",
    };
  }

  return {
    tone: "good",
    title: "Темп хороший",
    message: "Продовжуй лити рівномірно та слідкуй за ціллю етапу.",
    icon: "thumb-up",
  };
}

function getCurrentStepIndexByTime(steps: Recipe["steps"], elapsedSeconds: number) {
  let index = 0;

  steps.forEach((step, stepIndex) => {
    if (elapsedSeconds >= Number(step.start_time || 0)) {
      index = stepIndex;
    }
  });

  return index;
}

function getCurrentStepIndexByWeight(steps: Recipe["steps"], weight: number) {
  let cumulative = 0;

  for (let index = 0; index < steps.length; index += 1) {
    cumulative += Number(steps[index].water_volume || 0);

    if (weight < cumulative - 1) {
      return index;
    }
  }

  return Math.max(steps.length - 1, 0);
}

function getCumulativeTarget(steps: Recipe["steps"], exclusiveEndIndex: number) {
  return steps
    .slice(0, exclusiveEndIndex)
    .reduce((sum, step) => sum + Number(step.water_volume || 0), 0);
}

function getPlannedSeconds(steps: Recipe["steps"]) {
  if (steps.length === 0) {
    return 0;
  }

  const lastStep = steps[steps.length - 1];
  return Number(lastStep.start_time || 0) + Math.max(Number(lastStep.water_volume || 0), 20);
}

function getStepTitle(stepType?: string, index?: number) {
  const original = (stepType ?? "").trim();
  const normalized = original.toLowerCase();

  if (original && !STEP_ALIASES.has(normalized)) {
    return original;
  }

  if (normalized.includes("bloom")) {
    return "Блюмінг";
  }

  if (normalized.includes("wait") || normalized.includes("pause")) {
    return "Пауза";
  }

  if (normalized.includes("finish")) {
    return "Фініш";
  }

  return typeof index === "number" ? `Крок ${index + 1}` : "Крок";
}

function getStepInstruction(stepType: string | undefined, target: number, remaining: number) {
  if (isWaitStep(stepType)) {
    return "Зачекай, доки вода пройде крізь каву. Нову воду поки не додавай.";
  }

  if ((stepType ?? "").toLowerCase().includes("finish")) {
    return `Доведи вагу до ${target.toFixed(0)} г і зупини налив.`;
  }

  return `Повільно долий ще ${remaining.toFixed(0)} г до цілі ${target.toFixed(0)} г.`;
}

function isWaitStep(stepType?: string) {
  const normalized = (stepType ?? "").toLowerCase();
  return normalized.includes("wait") || normalized.includes("pause");
}

function formatDuration(totalSeconds: number) {
  const safeSeconds = Math.max(0, Math.floor(totalSeconds));
  const minutes = Math.floor(safeSeconds / 60);
  const seconds = safeSeconds % 60;
  return `${minutes}:${seconds.toString().padStart(2, "0")}`;
}

function getToneColor(tone: GuidanceTone) {
  switch (tone) {
    case "offline":
      return "#9B9B9B";
    case "stop":
      return "#D64D31";
    case "fast":
      return "#E36E49";
    case "slow":
      return "#DFA23C";
    case "wait":
      return "#6A7FDB";
    case "done":
      return "#4EBA61";
    case "good":
    default:
      return "#4EBA61";
  }
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#F8F3EC",
  },
  container: {
    flex: 1,
  },
  content: {
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 118,
  },
  centered: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  },
  loadingText: {
    marginTop: 12,
    color: "#5B514A",
    fontSize: 15,
    fontWeight: "600",
  },
  errorTitle: {
    color: "#171717",
    fontSize: 24,
    fontWeight: "800",
    marginBottom: 8,
  },
  errorText: {
    color: "#6E625A",
    textAlign: "center",
    fontSize: 15,
    lineHeight: 21,
    marginBottom: 18,
  },
  topBar: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  iconButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EEE0D4",
  },
  connectionPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 14,
    height: 38,
    borderRadius: 19,
    backgroundColor: "#E5F7E7",
    borderWidth: 1,
    borderColor: "#B8E9C0",
  },
  connectionPillOffline: {
    backgroundColor: "#E8E6E2",
    borderColor: "#D7D1CA",
  },
  connectionDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: "#4EBA61",
  },
  connectionDotOffline: {
    backgroundColor: "#9B9B9B",
  },
  connectionText: {
    color: "#171717",
    fontSize: 14,
    fontWeight: "800",
  },
  recipeName: {
    color: "#111111",
    fontSize: 32,
    fontWeight: "900",
    letterSpacing: 0,
  },
  recipeMeta: {
    color: "#71665F",
    fontSize: 15,
    fontWeight: "700",
    marginTop: 6,
    marginBottom: 16,
  },
  inlineError: {
    color: "#B5442D",
    fontSize: 13,
    fontWeight: "700",
    marginBottom: 10,
  },
  guidanceCard: {
    flexDirection: "row",
    gap: 14,
    alignItems: "center",
    borderRadius: 22,
    padding: 16,
    borderWidth: 1,
    marginBottom: 18,
  },
  guidance_offline: {
    backgroundColor: "#E7E4DF",
    borderColor: "#D4CEC6",
  },
  guidance_stop: {
    backgroundColor: "#FFE2D9",
    borderColor: "#ECA38D",
  },
  guidance_fast: {
    backgroundColor: "#FFE9DE",
    borderColor: "#F0B29B",
  },
  guidance_slow: {
    backgroundColor: "#FFF1CE",
    borderColor: "#EAC36A",
  },
  guidance_wait: {
    backgroundColor: "#E6EAFF",
    borderColor: "#B7C1F5",
  },
  guidance_done: {
    backgroundColor: "#E4F7E8",
    borderColor: "#A8E4B2",
  },
  guidance_good: {
    backgroundColor: "#EAF8E9",
    borderColor: "#BEE9BE",
  },
  guidanceIconWrap: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: "rgba(255,255,255,0.72)",
    alignItems: "center",
    justifyContent: "center",
  },
  guidanceTextWrap: {
    flex: 1,
  },
  guidanceTitle: {
    color: "#141414",
    fontSize: 18,
    fontWeight: "900",
  },
  guidanceMessage: {
    color: "#4E4640",
    fontSize: 14,
    lineHeight: 19,
    fontWeight: "600",
    marginTop: 4,
  },
  weightPanel: {
    alignItems: "center",
    justifyContent: "center",
    marginTop: 4,
    marginBottom: 18,
  },
  progressRing: {
    shadowColor: "#312117",
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.12,
    shadowRadius: 22,
  },
  weightCenter: {
    position: "absolute",
    alignItems: "center",
  },
  weightLabel: {
    color: "#7A6E64",
    fontSize: 14,
    fontWeight: "800",
    marginBottom: 4,
  },
  weightValue: {
    color: "#111111",
    fontSize: 42,
    fontWeight: "900",
  },
  weightHint: {
    color: "#7A6E64",
    fontSize: 15,
    fontWeight: "800",
    marginTop: 4,
  },
  metricsRow: {
    flexDirection: "row",
    gap: 10,
    marginBottom: 14,
  },
  metricCard: {
    flex: 1,
    minHeight: 74,
    borderRadius: 18,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EEE0D4",
    padding: 12,
    justifyContent: "center",
  },
  metricValue: {
    color: "#151515",
    fontSize: 18,
    fontWeight: "900",
  },
  metricLabel: {
    color: "#7A6E64",
    fontSize: 12,
    fontWeight: "800",
    marginTop: 4,
  },
  stepCard: {
    borderRadius: 24,
    backgroundColor: "#171717",
    padding: 18,
    marginBottom: 14,
  },
  stepHeader: {
    flexDirection: "row",
    alignItems: "flex-start",
    justifyContent: "space-between",
    gap: 16,
  },
  stepEyebrow: {
    color: "#F4B99A",
    fontSize: 13,
    fontWeight: "900",
    textTransform: "uppercase",
  },
  stepTitle: {
    color: "#FFFFFF",
    fontSize: 28,
    fontWeight: "900",
    marginTop: 4,
  },
  stepTime: {
    color: "#FFFFFF",
    fontSize: 22,
    fontWeight: "900",
  },
  stepInstruction: {
    color: "#F4EEE8",
    fontSize: 16,
    lineHeight: 23,
    fontWeight: "700",
    marginTop: 14,
  },
  progressTrack: {
    height: 10,
    borderRadius: 5,
    backgroundColor: "#3D3935",
    overflow: "hidden",
    marginTop: 18,
  },
  progressFill: {
    height: "100%",
    borderRadius: 5,
    backgroundColor: "#E36E49",
  },
  stepFooter: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginTop: 10,
  },
  stepFooterText: {
    color: "#CFC6BD",
    fontSize: 13,
    fontWeight: "700",
  },
  planCard: {
    borderRadius: 24,
    backgroundColor: "#FFFFFF",
    borderWidth: 1,
    borderColor: "#EEE0D4",
    padding: 16,
  },
  planTitle: {
    color: "#151515",
    fontSize: 20,
    fontWeight: "900",
    marginBottom: 10,
  },
  planRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    paddingVertical: 11,
    borderBottomWidth: 1,
    borderBottomColor: "#F1E8DF",
  },
  planRowActive: {
    backgroundColor: "#FFF2EA",
    marginHorizontal: -8,
    paddingHorizontal: 8,
    borderRadius: 16,
    borderBottomColor: "transparent",
  },
  planRowDone: {
    opacity: 0.72,
  },
  planNumber: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#F2EAE2",
  },
  planNumberActive: {
    backgroundColor: "#E36E49",
  },
  planNumberText: {
    color: "#6D625A",
    fontSize: 15,
    fontWeight: "900",
  },
  planNumberTextActive: {
    color: "#FFFFFF",
  },
  planBody: {
    flex: 1,
  },
  planStepTitle: {
    color: "#171717",
    fontSize: 16,
    fontWeight: "900",
  },
  planStepMeta: {
    color: "#7A6E64",
    fontSize: 13,
    fontWeight: "700",
    marginTop: 3,
  },
  bottomBar: {
    position: "absolute",
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 18,
    paddingTop: 12,
    paddingBottom: 24,
    backgroundColor: "rgba(248, 243, 236, 0.96)",
    borderTopWidth: 1,
    borderTopColor: "#EEE0D4",
  },
  finishButton: {
    height: 58,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#C9563F",
  },
  finishButtonDisabled: {
    opacity: 0.7,
  },
  finishButtonText: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "900",
  },
  secondaryButton: {
    height: 48,
    paddingHorizontal: 22,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#171717",
  },
  secondaryButtonText: {
    color: "#FFFFFF",
    fontSize: 15,
    fontWeight: "900",
  },
});
