import { API_URL } from "./auth";
import { getAccessToken } from "../storage/authToken";

export type ReviewSession = {
  id: number;
  recipe_id: number;
  recipe_name: string;
  brew_method: string;
  recipe_total_time: string;
  brewed_time?: string | null;
  brewed_seconds?: number | null;
  water_temp: number;
  coffee_grams: number;
  start_time: string;
  end_time?: string | null;
  brew_description?: string | null;
  rating?: number | null;
  review_text?: string | null;
  is_favorite: boolean;
  max_weight?: number | null;
  latest_weight?: number | null;
  max_pour_rate?: number | null;
};

export type BrewingSession = {
  id: number;
  user_id: number;
  recipe_id: number;
  scale_id?: number | null;
  start_time: string;
  end_time?: string | null;
  current_step: number;
  status: string;
  brew_description?: string | null;
  rating?: number | null;
  review_text?: string | null;
  is_favorite: boolean;
};

export async function createBrewingSession(recipeId: number, scaleId?: number | null): Promise<BrewingSession> {
  const token = await getAccessToken();

  if (!token) {
    throw new Error("No access token");
  }

  let response: Response;

  try {
    response = await fetch(`${API_URL}/sessions/`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({
        recipe_id: recipeId,
        scale_id: scaleId ?? null
      })
    });
  } catch {
    throw new Error(`Не вдалося підключитись до API (${API_URL}).`);
  }

  if (!response.ok) {
    throw new Error("Не вдалося створити сеанс заварювання.");
  }

  return response.json() as Promise<BrewingSession>;
}

export async function advanceBrewingSession(sessionId: number): Promise<BrewingSession> {
  const token = await getAccessToken();

  if (!token) {
    throw new Error("No access token");
  }

  let response: Response;

  try {
    response = await fetch(`${API_URL}/sessions/${sessionId}/next-step`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  } catch {
    throw new Error(`Не вдалося підключитись до API (${API_URL}).`);
  }

  if (!response.ok) {
    throw new Error("Не вдалося перейти до наступного кроку.");
  }

  return response.json() as Promise<BrewingSession>;
}

export async function completeBrewingSession(sessionId: number): Promise<BrewingSession> {
  const token = await getAccessToken();

  if (!token) {
    throw new Error("No access token");
  }

  let response: Response;

  try {
    response = await fetch(`${API_URL}/sessions/${sessionId}`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify({ status: "completed" })
    });
  } catch {
    throw new Error(`Не вдалося підключитись до API (${API_URL}).`);
  }

  if (!response.ok) {
    throw new Error("Не вдалося завершити заварювання.");
  }

  return response.json() as Promise<BrewingSession>;
}

export function getSensorWebSocketUrl(sessionId: number) {
  const url = new URL(API_URL);
  url.protocol = url.protocol === "https:" ? "wss:" : "ws:";
  url.pathname = `/sensor-data/ws/${sessionId}`;
  url.search = "";
  url.hash = "";
  return url.toString();
}

export async function getReviewSessions(favoriteOnly = false): Promise<ReviewSession[]> {
  const token = await getAccessToken();

  if (!token) {
    throw new Error("No access token");
  }

  let response: Response;

  try {
    response = await fetch(`${API_URL}/sessions/review?favorite_only=${favoriteOnly ? "true" : "false"}`, {
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  } catch {
    throw new Error(`Не вдалося підключитись до API (${API_URL}).`);
  }

  if (!response.ok) {
    throw new Error("Не вдалося завантажити журнал заварювань.");
  }

  return response.json() as Promise<ReviewSession[]>;
}

export async function updateReviewSession(
  sessionId: number,
  payload: { brew_description?: string | null; rating?: number; review_text?: string | null; is_favorite?: boolean }
): Promise<ReviewSession> {
  const token = await getAccessToken();

  if (!token) {
    throw new Error("No access token");
  }

  let response: Response;

  try {
    response = await fetch(`${API_URL}/sessions/${sessionId}/review`, {
      method: "PATCH",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });
  } catch {
    throw new Error(`Не вдалося підключитись до API (${API_URL}).`);
  }

  if (!response.ok) {
    throw new Error("Не вдалося оновити оцінку заварювання.");
  }

  return response.json() as Promise<ReviewSession>;
}

export async function deleteBrewingSession(sessionId: number): Promise<void> {
  const token = await getAccessToken();

  if (!token) {
    throw new Error("No access token");
  }

  let response: Response;

  try {
    response = await fetch(`${API_URL}/sessions/${sessionId}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${token}`
      }
    });
  } catch {
    throw new Error(`Не вдалося підключитись до API (${API_URL}).`);
  }

  if (!response.ok) {
    throw new Error("Не вдалося видалити запис із журналу.");
  }
}
