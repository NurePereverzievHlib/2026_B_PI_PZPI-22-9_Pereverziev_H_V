from sqlalchemy import Boolean, Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from app.db.database import Base
from datetime import datetime

class BrewingSession(Base):
    __tablename__ = "brewing_sessions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    recipe_id = Column(Integer, ForeignKey("recipes.id", ondelete="CASCADE"), nullable=False)
    scale_id = Column(Integer, ForeignKey("scales.id", ondelete="SET NULL"), nullable=True)
    start_time = Column(DateTime, default=datetime.utcnow)
    end_time = Column(DateTime, nullable=True)
    current_step = Column(Integer, default=0)
    status = Column(String, default="in_progress")  # in_progress, completed
    brew_description = Column(String, nullable=True)
    rating = Column(Integer, nullable=True)
    review_text = Column(String, nullable=True)
    is_favorite = Column(Boolean, nullable=False, default=False)

    user = relationship("User", back_populates="brewing_sessions")
    recipe = relationship("Recipe", back_populates="brewing_sessions")
    scale = relationship("Scale", back_populates="brewing_sessions")
    sensor_logs = relationship(
        "SensorData",
        back_populates="session",
        cascade="all, delete-orphan"
    )
